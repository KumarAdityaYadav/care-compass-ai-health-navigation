import { CareType, Urgency, DetectedLanguage } from '../types/triage.ts';

export interface TrainingSample {
  id: string;
  detected_language: DetectedLanguage;
  user_input: string;
  lat: number;
  lng: number;
  care_type: CareType;
  urgency: Urgency;
  red_flags: string[];
  follow_up_question: string | null;
  reasoning: string;
  matched_caregiver_ids: string[];
  top_score: number | null;
}

// Full 340 samples from triage_dataset_flat_1a567311.csv
export const RAW_TRAINING_CSV = `id,detected_language,user_input,lat,lng,care_type,urgency,red_flags,follow_up_question,reasoning,matched_caregiver_ids,top_score
S0001,English,"Doctor prescribed an injection, can someone come home",28.5164,77.2605,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0002,English,"Mild acidity and gas since morning, want to consult a doctor",28.4605,77.0883,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0003,English,Grandmother has a bedsore that needs dressing,28.5069,77.2092,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_016,0.98
S0004,Hinglish,accident ke baad bleeding ruk nahi rahi,28.5366,77.255,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0005,English,Grandmother has a bedsore that needs dressing,28.6186,77.3578,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_026,0.93
S0006,Hindi,"सुबह से एसिडिटी है, डॉक्टर से सलाह चाहिए",28.6111,77.3748,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0007,English,Insulin injection help needed for elderly father,28.5947,77.0508,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_019;CG_014,0.87
S0008,Hinglish,wo achanak gir gaye response nahi de rahe,28.6076,77.3079,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0009,Hindi,घर पर इंजेक्शन लगवाना है,28.635,77.3618,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.85
S0010,Hinglish,doctor ne injection likha hai koi ghar aa sakta hai,28.6182,77.2825,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_035,0.66
S0011,Hinglish,mummy ka bp sugar ghar pe check karwana hai,28.6373,77.3581,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042;CG_060,0.84
S0012,English,"Book a full body checkup, home collection",28.6027,77.0489,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.84
S0013,Hinglish,doctor ne injection likha hai koi ghar aa sakta hai,28.6509,77.2019,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_035,0.88
S0014,English,I want to book something for my mother,28.6499,77.3536,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0015,Hinglish,accident ke baad bleeding ruk nahi rahi,28.6334,77.3664,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0016,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.6362,77.3754,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0017,English,Want a CBC and thyroid test with home sample collection,28.7212,77.1019,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0018,Hindi,मदद चाहिए,28.625,77.374,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0019,Hindi,माँ के लिए कुछ बुक करना है,28.544,77.2139,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0020,English,Need wound dressing at home after surgery,28.6131,77.3783,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_026,0.92
S0021,Hinglish,cbc aur thyroid test ghar se sample lekar,28.7273,77.0978,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0022,Hinglish,papa ko insulin injection chahiye ghar pe,28.6271,77.2986,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0023,Hinglish,"subah se acidity gas hai, doctor se consult karna hai",28.5318,77.2739,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0024,Hinglish,doctor chahiye,28.5205,77.1907,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0025,English,My father has had fever and cough for 2 days,28.4766,77.0754,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_050;CG_024,0.85
S0026,English,My father has had fever and cough for 2 days,28.6371,77.1741,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_035;CG_052,0.88
S0027,English,Want to talk to a doctor about my reports,28.4836,77.0769,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0028,Hinglish,doctor ne injection likha hai koi ghar aa sakta hai,28.6269,77.385,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.82
S0029,Hindi,कल सुबह शुगर टेस्ट घर पर,28.5779,77.056,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.88
S0030,Hindi,पापा को इंसुलिन लगवाना है,28.6277,77.3602,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.83
S0031,English,Insulin injection help needed for elderly father,28.4006,77.3193,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0032,English,Heavy bleeding that won't stop after an accident,28.7367,77.1283,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0033,English,Insulin injection help needed for elderly father,28.3952,77.3022,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0034,English,Want to talk to a doctor about my reports,28.5341,77.1957,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0035,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.5531,77.2707,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_054;CG_011,0.85
S0036,English,Insulin injection help needed for elderly father,28.6693,77.1879,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_035;CG_052;CG_014,0.93
S0037,Hindi,घर पर इंजेक्शन लगवाना है,28.4631,77.0898,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_038;CG_057,0.82
S0038,Hindi,दादी को घाव की ड्रेसिंग चाहिए,28.6646,77.1892,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.71
S0039,Hinglish,ghar pe IM injection lagwana hai,28.6085,77.0573,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.88
S0040,English,Need blood sugar test at home tomorrow morning,28.5925,77.3088,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_011;CG_022;CG_054,0.88
S0041,Hindi,कल सुबह शुगर टेस्ट घर पर,28.6011,77.0328,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.83
S0042,English,"Grandfather is weak and not eating, want a home check-up",28.6543,77.3568,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042,0.83
S0043,Hinglish,kal subah sugar test ghar pe,28.6289,77.3572,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055,0.8
S0044,Hinglish,help chahiye,28.394,77.2946,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0045,English,I need help,28.7245,77.112,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0046,Hinglish,doctor ne injection likha hai koi ghar aa sakta hai,28.6094,77.3816,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.78
S0047,Hinglish,accident ke baad bleeding ruk nahi rahi,28.5376,77.2217,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0048,Hinglish,operation ke baad ghar pe dressing karani hai,28.3844,77.3239,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0049,English,Want to talk to a doctor about my reports,28.6127,77.3768,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0050,English,Need a second opinion on my child's prescription,28.3852,77.3083,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0051,English,Want to talk to a doctor about my reports,28.4701,77.1019,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0052,Hinglish,cbc aur thyroid test ghar se sample lekar,28.5898,77.0505,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.87
S0053,Hinglish,reports ke baare me doctor se baat karni hai,28.7341,77.1133,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0054,English,"Mild acidity and gas since morning, want to consult a doctor",28.3991,77.3267,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0055,English,Need a second opinion on my child's prescription,28.6237,77.3677,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0056,Hinglish,papa ko do din se bukhar hai aur khansi bhi,28.5074,77.2134,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_024,0.79
S0057,English,I want to book something for my mother,28.6171,77.3575,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0058,Hinglish,operation ke baad ghar pe dressing karani hai,28.5399,77.1931,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_028;CG_016;CG_032,0.92
S0059,English,"Hi, is anyone there?",28.5443,77.2028,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0060,Hindi,पत्नी की पट्टी बदलवानी है घर पर,28.601,77.0268,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_019;CG_014,0.81
S0061,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.5289,77.2598,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_023;CG_005,0.86
S0062,English,Want to talk to a doctor about my reports,28.4979,77.0752,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0063,English,Need an IM injection given at home,28.7462,77.1248,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052;CG_020;CG_035,0.91
S0064,Hindi,डॉक्टर चाहिए,28.6285,77.3726,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0065,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.7183,77.1195,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0066,English,Need blood sugar test at home tomorrow morning,28.5389,77.2712,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_054,0.85
S0067,English,Want to talk to a doctor about my reports,28.7505,77.1102,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0068,Hindi,बच्चे की दवा पर सेकंड ओपिनियन चाहिए,28.6362,77.1911,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0069,English,Need someone to check BP and sugar at home for my mother,28.5207,77.2764,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_033;CG_032;CG_024,0.77
S0070,Hinglish,ghar pe IM injection lagwana hai,28.7338,77.1189,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052;CG_020,0.94
S0071,English,"Doctor prescribed an injection, can someone come home",28.5141,77.2684,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0072,Hinglish,wife ki post-op dressing change karwani hai,28.4964,77.0753,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057;CG_041;CG_050,0.92
S0073,Hinglish,kal subah sugar test ghar pe,28.3974,77.3047,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_004,0.8
S0074,Hinglish,ghar pe IM injection lagwana hai,28.4727,77.1043,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057;CG_050;CG_038,0.83
S0075,Hinglish,papa ko severe chest pain hai saans nahi aa rahi,28.5441,77.2259,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0076,English,I need help,28.5971,77.0612,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0077,English,Need wound dressing at home after surgery,28.5393,77.2134,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_016;CG_028,0.9
S0078,English,"Mild acidity and gas since morning, want to consult a doctor",28.7178,77.0994,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0079,English,Need blood sugar test at home tomorrow morning,28.6275,77.3099,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_022;CG_011;CG_054,0.82
S0080,English,Need an IM injection given at home,28.7247,77.0993,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052;CG_020,0.91
S0081,English,Need blood sugar test at home tomorrow morning,28.7361,77.1,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0082,English,I need help,28.7487,77.0978,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0083,English,Need blood sugar test at home tomorrow morning,28.7412,77.0954,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0084,English,Doctor chahiye,28.6178,77.2908,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0085,Hinglish,accident ke baad bleeding ruk nahi rahi,28.6088,77.3854,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0086,Hinglish,bacche ki medicine pe second opinion chahiye,28.3696,77.31,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0087,English,"Mild acidity and gas since morning, want to consult a doctor",28.6629,77.1984,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0088,English,My father is having severe chest pain and can't breathe,28.5152,77.2646,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0089,Hindi,माँ का बीपी और शुगर घर पर चेक करवाना है,28.366,77.2898,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_034,0.75
S0090,English,He suddenly collapsed and is not responding,28.7161,77.1239,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0091,Hinglish,accident ke baad bleeding ruk nahi rahi,28.5985,77.0286,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0092,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.6059,77.0354,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0093,English,"Hi, is anyone there?",28.6418,77.3663,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0094,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.6563,77.1779,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0095,English,Need a second opinion on my child's prescription,28.7421,77.1197,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0096,English,Want to talk to a doctor about my reports,28.6244,77.3618,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0097,Hinglish,papa ko do din se bukhar hai aur khansi bhi,28.6336,77.3717,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042;CG_060,0.85
S0098,Hindi,सीबीसी और थायराइड टेस्ट घर से सैंपल लेकर,28.372,77.3281,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_004,0.81
S0099,Hindi,माँ का बीपी और शुगर घर पर चेक करवाना है,28.6049,77.0647,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_019;CG_046,0.87
S0100,Hindi,घर पर इंजेक्शन लगवाना है,28.462,77.0746,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_038;CG_057;CG_050,0.85
S0101,Hindi,बच्चे की दवा पर सेकंड ओपिनियन चाहिए,28.6311,77.3773,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0102,Hinglish,mummy ka bp sugar ghar pe check karwana hai,28.4789,77.106,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_050;CG_024,0.81
S0103,English,My father has had fever and cough for 2 days,28.6493,77.3672,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042;CG_060,0.85
S0104,Hindi,पत्नी की पट्टी बदलवानी है घर पर,28.5171,77.2202,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_016,0.96
S0105,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.6097,77.0338,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.82
S0106,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.5916,77.2866,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0107,Hinglish,help chahiye,28.626,77.3012,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0108,English,Need an IM injection given at home,28.7414,77.098,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_020;CG_052,0.93
S0109,Hinglish,kal subah sugar test ghar pe,28.4899,77.1024,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_025;CG_044,0.77
S0110,Hinglish,mummy ka bp sugar ghar pe check karwana hai,28.386,77.3178,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_034,0.84
S0111,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.6611,77.1958,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0112,Hindi,घर पर इंजेक्शन लगवाना है,28.3691,77.3079,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0113,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.7322,77.1015,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_020;CG_052,0.91
S0114,Hinglish,bacche ki medicine pe second opinion chahiye,28.5788,77.0325,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0115,Hindi,"सुबह से एसिडिटी है, डॉक्टर से सलाह चाहिए",28.4771,77.0843,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0116,English,"Book a full body checkup, home collection",28.4688,77.078,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_025;CG_044,0.85
S0117,Hindi,पापा को दो दिन से बुखार और खांसी है,28.5993,77.2938,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_060,0.81
S0118,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.5343,77.195,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0119,Hindi,घर पर इंजेक्शन लगवाना है,28.6331,77.3897,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.82
S0120,Hinglish,accident ke baad bleeding ruk nahi rahi,28.4627,77.1069,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0121,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.6393,77.3635,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055,0.82
S0122,English,Post-operative dressing change required for my wife,28.6607,77.3706,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_026,0.92
S0123,Hinglish,kal subah sugar test ghar pe,28.6319,77.3554,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055,0.81
S0124,Hinglish,dadi ko bedsore dressing chahiye,28.6098,77.0549,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014;CG_019,0.87
S0125,Hindi,मदद चाहिए,28.3951,77.2891,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0126,Hinglish,operation ke baad ghar pe dressing karani hai,28.7545,77.1171,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0127,Hindi,एक्सीडेंट के बाद खून नहीं रुक रहा,28.5761,77.038,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0128,English,Need a second opinion on my child's prescription,28.7249,77.116,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0129,Hindi,बच्चे की दवा पर सेकंड ओपिनियन चाहिए,28.7544,77.1178,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0130,Hinglish,cbc aur thyroid test ghar se sample lekar,28.3739,77.3274,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_004,0.81
S0131,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.5213,77.2745,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0132,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.7251,77.109,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0133,English,"Doctor prescribed an injection, can someone come home",28.5413,77.2678,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0134,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.5454,77.2687,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0135,English,Want to talk to a doctor about my reports,28.6608,77.3635,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0136,Hindi,ऑपरेशन के बाद घर पर ड्रेसिंग करवानी है,28.7464,77.1038,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0137,Hinglish,cbc aur thyroid test ghar se sample lekar,28.4784,77.1074,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_025,0.78
S0138,English,Need a second opinion on my child's prescription,28.522,77.2781,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0139,English,"Book a full body checkup, home collection",28.5209,77.2571,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_023;CG_005;CG_018,0.85
S0140,Hinglish,ghar pe IM injection lagwana hai,28.6094,77.0392,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.83
S0141,Hinglish,accident ke baad bleeding ruk nahi rahi,28.6233,77.3776,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0142,Hindi,कल सुबह शुगर टेस्ट घर पर,28.6288,77.3511,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055;CG_011,0.79
S0143,Hindi,माँ का बीपी और शुगर घर पर चेक करवाना है,28.5945,77.0564,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_019;CG_046,0.88
S0144,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.5741,77.0449,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_019;CG_014,0.83
S0145,Hindi,रिपोर्ट के बारे में डॉक्टर से बात करनी है,28.6036,77.3069,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0146,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.5061,77.188,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0147,English,Need someone to check BP and sugar at home for my mother,28.4889,77.1069,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_050;CG_024,0.81
S0148,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.6327,77.1999,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_035;CG_014,0.85
S0149,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.5424,77.2629,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0150,English,My father has had fever and cough for 2 days,28.5911,77.0643,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_019;CG_046,0.89
S0151,Hindi,डॉक्टर चाहिए,28.6273,77.3709,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0152,Hinglish,mummy ke liye kuch book karna hai,28.6313,77.3651,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0153,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.5926,77.0417,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.86
S0154,Hindi,ऑपरेशन के बाद घर पर ड्रेसिंग करवानी है,28.5328,77.2609,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_048,0.91
S0155,English,Want a CBC and thyroid test with home sample collection,28.741,77.1003,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0156,Hinglish,kal subah sugar test ghar pe,28.6164,77.3687,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_011;CG_055;CG_022,0.79
S0157,English,Heavy bleeding that won't stop after an accident,28.3979,77.3156,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0158,Hindi,माँ का बीपी और शुगर घर पर चेक करवाना है,28.7387,77.1069,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_052;CG_035,0.91
S0159,English,"Doctor prescribed an injection, can someone come home",28.4664,77.0804,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_038;CG_057,0.84
S0160,English,Need a second opinion on my child's prescription,28.5879,77.0657,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0161,English,"Mild acidity and gas since morning, want to consult a doctor",28.5982,77.0656,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0162,Hindi,पापा को दो दिन से बुखार और खांसी है,28.6586,77.3526,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042,0.81
S0163,English,Need wound dressing at home after surgery,28.483,77.1041,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057,0.85
S0164,Hindi,"दादाजी कमजोर हैं, घर पर जांच चाहिए",28.625,77.3624,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042;CG_060,0.82
S0165,English,"Grandfather is weak and not eating, want a home check-up",28.6594,77.184,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_035,0.93
S0166,Hindi,घर पर इंजेक्शन लगवाना है,28.5217,77.2493,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0167,Hinglish,papa ko severe chest pain hai saans nahi aa rahi,28.5463,77.2555,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0168,English,Insulin injection help needed for elderly father,28.7191,77.0933,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052;CG_020,0.9
S0169,Hindi,रिपोर्ट के बारे में डॉक्टर से बात करनी है,28.5086,77.2024,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0170,Hinglish,dadi ko bedsore dressing chahiye,28.5982,77.0419,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_019;CG_014,0.85
S0171,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.7327,77.0941,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0172,Hindi,बच्चे की दवा पर सेकंड ओपिनियन चाहिए,28.5052,77.2173,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0173,English,He suddenly collapsed and is not responding,28.5126,77.1868,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0174,Hindi,ऑपरेशन के बाद घर पर ड्रेसिंग करवानी है,28.5883,77.0613,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_019;CG_014,0.88
S0175,English,"Hi, is anyone there?",28.5156,77.2448,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0176,Hinglish,"dadaji weak hain, ghar pe checkup chahiye",28.6185,77.2779,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_060;CG_032,0.75
S0177,English,Insulin injection help needed for elderly father,28.644,77.3564,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.84
S0178,English,I want to book something for my mother,28.6405,77.3537,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0179,English,Insulin injection help needed for elderly father,28.508,77.2151,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0180,English,"Hi, is anyone there?",28.6472,77.2039,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0181,Hinglish,operation ke baad ghar pe dressing karani hai,28.5295,77.2598,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_048;CG_016,0.9
S0182,English,Need an IM injection given at home,28.4978,77.1036,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057,0.86
S0183,Hinglish,"dadaji weak hain, ghar pe checkup chahiye",28.5402,77.2521,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_032;CG_033,0.83
S0184,Hindi,"सुबह से एसिडिटी है, डॉक्टर से सलाह चाहिए",28.742,77.1043,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0185,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.6069,77.2885,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_022,0.84
S0186,Hinglish,mummy ka bp sugar ghar pe check karwana hai,28.6314,77.3815,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_042;CG_060,0.84
S0187,English,Doctor chahiye,28.5088,77.1917,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0188,English,"Doctor prescribed an injection, can someone come home",28.3844,77.2906,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0189,English,Grandmother has a bedsore that needs dressing,28.6201,77.2915,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_060,0.78
S0190,Hinglish,doctor chahiye,28.608,77.3547,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0191,English,Post-operative dressing change required for my wife,28.7543,77.1286,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0192,Hinglish,papa ko severe chest pain hai saans nahi aa rahi,28.6054,77.0504,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0193,English,"Doctor prescribed an injection, can someone come home",28.642,77.2026,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_035,0.86
S0194,Hinglish,doctor ne injection likha hai koi ghar aa sakta hai,28.4827,77.0956,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057,0.86
S0195,Hindi,घर पर इंजेक्शन लगवाना है,28.4663,77.0774,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_038;CG_057,0.85
S0196,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.6387,77.3626,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0197,Hinglish,help chahiye,28.6276,77.2891,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0198,Hinglish,papa ko insulin injection chahiye ghar pe,28.534,77.2015,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0199,Hinglish,ghar pe IM injection lagwana hai,28.6022,77.2743,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0200,Hinglish,dadi ko bedsore dressing chahiye,28.5254,77.2597,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_048;CG_016,0.89
S0201,Hinglish,accident ke baad bleeding ruk nahi rahi,28.6183,77.3009,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0202,English,Post-operative dressing change required for my wife,28.656,77.1867,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.72
S0203,English,Need someone to check BP and sugar at home for my mother,28.4835,77.0728,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_050,0.87
S0204,Hinglish,mummy ka bp sugar ghar pe check karwana hai,28.7203,77.1063,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_052,0.93
S0205,Hinglish,kal subah sugar test ghar pe,28.6363,77.1846,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_043,0.81
S0206,English,Need wound dressing at home after surgery,28.4873,77.089,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057,0.88
S0207,English,Heavy bleeding that won't stop after an accident,28.7321,77.1026,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0208,English,"Grandfather is weak and not eating, want a home check-up",28.3997,77.3128,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_034,0.82
S0209,Hinglish,full body checkup home collection,28.6319,77.3871,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055,0.78
S0210,Hinglish,papa ko do din se bukhar hai aur khansi bhi,28.5119,77.193,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_024,0.83
S0211,Hinglish,"dadaji weak hain, ghar pe checkup chahiye",28.4647,77.079,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_050,0.82
S0212,Hinglish,accident ke baad bleeding ruk nahi rahi,28.537,77.1936,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0213,English,"Doctor prescribed an injection, can someone come home",28.5533,77.2681,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0214,Hinglish,papa ko severe chest pain hai saans nahi aa rahi,28.5383,77.2164,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0215,English,"Book a full body checkup, home collection",28.629,77.3909,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055;CG_011,0.76
S0216,Hinglish,operation ke baad ghar pe dressing karani hai,28.5855,77.056,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_019;CG_014,0.87
S0217,Hindi,मदद चाहिए,28.7414,77.1192,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0218,Hinglish,ghar pe IM injection lagwana hai,28.6073,77.0266,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014;CG_019,0.8
S0219,Hinglish,operation ke baad ghar pe dressing karani hai,28.6368,77.3651,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_026;CG_010,0.99
S0220,Hinglish,ghar pe IM injection lagwana hai,28.5408,77.2118,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0221,Hinglish,wo achanak gir gaye response nahi de rahe,28.6556,77.3789,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0222,English,Doctor chahiye,28.4818,77.0833,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0223,Hinglish,full body checkup home collection,28.5947,77.0329,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.84
S0224,English,My father has had fever and cough for 2 days,28.6682,77.1838,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_035,0.94
S0225,English,My father is having severe chest pain and can't breathe,28.519,77.2648,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0226,Hinglish,papa ko do din se bukhar hai aur khansi bhi,28.5161,77.2627,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_032;CG_033,0.76
S0227,Hinglish,dadi ko bedsore dressing chahiye,28.6073,77.0562,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014;CG_019,0.87
S0228,English,Want a CBC and thyroid test with home sample collection,28.4671,77.0724,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_025;CG_044,0.87
S0229,Hinglish,"dadaji weak hain, ghar pe checkup chahiye",28.7351,77.0973,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_052;CG_035,0.9
S0230,Hindi,पत्नी की पट्टी बदलवानी है घर पर,28.606,77.2718,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_060;CG_032,0.75
S0231,English,Insulin injection help needed for elderly father,28.6254,77.3018,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0232,Hindi,बच्चे की दवा पर सेकंड ओपिनियन चाहिए,28.6608,77.2016,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0233,Hinglish,cbc aur thyroid test ghar se sample lekar,28.6078,77.2729,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_022;CG_011;CG_023,0.81
S0234,Hinglish,operation ke baad ghar pe dressing karani hai,28.6638,77.1768,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.73
S0235,English,Need a second opinion on my child's prescription,28.5137,77.2587,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0236,English,He suddenly collapsed and is not responding,28.6449,77.2033,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0237,Hinglish,ghar pe IM injection lagwana hai,28.7486,77.1295,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052,0.91
S0238,English,Want a CBC and thyroid test with home sample collection,28.5917,77.0656,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_006,0.85
S0239,English,I want to book something for my mother,28.5928,77.3081,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0240,Hinglish,cbc aur thyroid test ghar se sample lekar,28.5972,77.2815,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_011;CG_022;CG_023,0.83
S0241,English,Need a second opinion on my child's prescription,28.4968,77.0761,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0242,Hinglish,help chahiye,28.6123,77.2919,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0243,Hinglish,accident ke baad bleeding ruk nahi rahi,28.5958,77.2886,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0244,Hindi,"नमस्ते, कोई है?",28.6204,77.3777,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0245,English,Need a second opinion on my child's prescription,28.7462,77.1251,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0246,Hinglish,operation ke baad ghar pe dressing karani hai,28.4879,77.0951,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057;CG_041,0.87
S0247,English,Post-operative dressing change required for my wife,28.4693,77.1092,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_041,0.82
S0248,Hinglish,operation ke baad ghar pe dressing karani hai,28.4744,77.1104,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057;CG_041,0.82
S0249,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.7238,77.1175,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0250,Hindi,पापा को दो दिन से बुखार और खांसी है,28.5231,77.1871,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_024;CG_032,0.86
S0251,English,Heavy bleeding that won't stop after an accident,28.7345,77.0977,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0252,Hinglish,bacche ki medicine pe second opinion chahiye,28.5431,77.2754,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0253,Hinglish,accident ke baad bleeding ruk nahi rahi,28.5383,77.2133,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0254,Hinglish,accident ke baad bleeding ruk nahi rahi,28.6651,77.1972,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0255,English,He suddenly collapsed and is not responding,28.517,77.2117,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0256,Hindi,पापा को दो दिन से बुखार और खांसी है,28.533,77.2118,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_024;CG_032,0.81
S0257,Hindi,डॉक्टर चाहिए,28.6228,77.3853,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0258,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.5378,77.2229,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0259,English,Need someone to check BP and sugar at home for my mother,28.3727,77.3176,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_034,0.81
S0260,Hindi,रिपोर्ट के बारे में डॉक्टर से बात करनी है,28.6493,77.1782,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0261,English,"Mild acidity and gas since morning, want to consult a doctor",28.6099,77.2874,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0262,Hinglish,operation ke baad ghar pe dressing karani hai,28.5251,77.2239,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_016;CG_028;CG_048,0.93
S0263,Hindi,"सुबह से एसिडिटी है, डॉक्टर से सलाह चाहिए",28.5236,77.2544,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0264,English,Need someone to check BP and sugar at home for my mother,28.5296,77.2136,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_024;CG_032;CG_033,0.8
S0265,English,Need an IM injection given at home,28.7457,77.1296,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052;CG_020;CG_035,0.92
S0266,Hindi,पत्नी की पट्टी बदलवानी है घर पर,28.4656,77.1082,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_041,0.82
S0267,Hinglish,hello koi hai?,28.6477,77.3798,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0268,Hinglish,papa ko insulin injection chahiye ghar pe,28.5232,77.1984,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0269,English,He suddenly collapsed and is not responding,28.6203,77.2802,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0270,Hindi,एक्सीडेंट के बाद खून नहीं रुक रहा,28.7553,77.1192,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0271,English,"Book a full body checkup, home collection",28.7303,77.1182,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_043,0.68
S0272,Hindi,कल सुबह शुगर टेस्ट घर पर,28.6565,77.1964,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_043,0.87
S0273,Hindi,पत्नी की पट्टी बदलवानी है घर पर,28.5169,77.2617,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_016;CG_048,0.87
S0274,English,I want to book something for my mother,28.6316,77.1705,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0275,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.6351,77.1757,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0276,English,Post-operative dressing change required for my wife,28.6204,77.2793,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_060;CG_032,0.76
S0277,Hinglish,hello koi hai?,28.6666,77.1943,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0278,Hinglish,accident ke baad bleeding ruk nahi rahi,28.7239,77.1197,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0279,English,"Mild acidity and gas since morning, want to consult a doctor",28.6488,77.3557,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0280,Hindi,घर पर इंजेक्शन लगवाना है,28.6259,77.3743,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.83
S0281,English,"Book a full body checkup, home collection",28.6319,77.3576,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055;CG_011;CG_022,0.81
S0282,Hinglish,help chahiye,28.6406,77.3707,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0283,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.606,77.311,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0284,English,My father is having severe chest pain and can't breathe,28.6144,77.2721,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0285,English,"Mild acidity and gas since morning, want to consult a doctor",28.6213,77.2748,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0286,English,Want a CBC and thyroid test with home sample collection,28.4877,77.096,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_025;CG_044,0.79
S0287,Hinglish,mummy ka bp sugar ghar pe check karwana hai,28.608,77.292,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_060,0.8
S0288,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.5146,77.1887,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0289,Hindi,"डॉक्टर ने इंजेक्शन लिखा है, घर कोई आ सकता है",28.5178,77.226,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0290,English,Insulin injection help needed for elderly father,28.6537,77.3642,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.84
S0291,Hindi,पापा को तेज सीने में दर्द है और सांस नहीं आ रही,28.6699,77.1735,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0292,Hindi,"दादाजी कमजोर हैं, घर पर जांच चाहिए",28.3994,77.3108,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_034,0.82
S0293,Hindi,सीबीसी और थायराइड टेस्ट घर से सैंपल लेकर,28.5154,77.272,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_023;CG_005,0.82
S0294,Hinglish,reports ke baare me doctor se baat karni hai,28.4004,77.3135,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0295,Hinglish,dadi ko bedsore dressing chahiye,28.6661,77.1733,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.73
S0296,Hinglish,wo achanak gir gaye response nahi de rahe,28.6111,77.3593,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0297,Hindi,पापा को दो दिन से बुखार और खांसी है,28.5283,77.272,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_033;CG_032,0.79
S0298,Hinglish,bacche ki medicine pe second opinion chahiye,28.7234,77.0934,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021,0.99
S0299,Hinglish,full body checkup home collection,28.6684,77.1722,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_043,0.87
S0300,English,Want to talk to a doctor about my reports,28.5275,77.2233,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0301,English,"Grandfather is weak and not eating, want a home check-up",28.5283,77.2263,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_032;CG_024;CG_033,0.79
S0302,Hindi,पत्नी की पट्टी बदलवानी है घर पर,28.3681,77.3148,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0303,Hinglish,operation ke baad ghar pe dressing karani hai,28.5047,77.214,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_016,0.99
S0304,English,"Hi, is anyone there?",28.5773,77.0267,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0305,Hinglish,full body checkup home collection,28.6439,77.3666,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_055;CG_011,0.83
S0306,Hinglish,papa ko severe chest pain hai saans nahi aa rahi,28.5838,77.0483,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0307,Hindi,फुल बॉडी चेकअप घर से सैंपल,28.7525,77.0941,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0308,English,My father has had fever and cough for 2 days,28.6342,77.1824,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_035;CG_024;CG_033,0.87
S0309,English,Need a second opinion on my child's prescription,28.6334,77.1847,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0310,Hindi,वो अचानक गिर गए और जवाब नहीं दे रहे,28.6128,77.3839,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0311,Hinglish,ghar pe IM injection lagwana hai,28.5236,77.2177,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0312,Hinglish,doctor ne injection likha hai koi ghar aa sakta hai,28.7272,77.1169,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_052;CG_020;CG_035,0.95
S0313,Hinglish,wo achanak gir gaye response nahi de rahe,28.66,77.1706,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0314,Hinglish,wife ki post-op dressing change karwani hai,28.6481,77.2055,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_014,0.69
S0315,Hinglish,kal subah sugar test ghar pe,28.6619,77.1794,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_043,0.88
S0316,Hinglish,ghar pe IM injection lagwana hai,28.5995,77.2879,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,,
S0317,English,I want to book something for my mother,28.6395,77.3867,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0318,Hinglish,papa ko insulin injection chahiye ghar pe,28.6359,77.3544,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_042,0.83
S0319,Hindi,सीबीसी और थायराइड टेस्ट घर से सैंपल लेकर,28.4714,77.0733,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_025;CG_044,0.86
S0320,Hinglish,cbc aur thyroid test ghar se sample lekar,28.7395,77.0924,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0321,Hinglish,cbc aur thyroid test ghar se sample lekar,28.3963,77.3199,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,CG_004,0.79
S0322,Hinglish,full body checkup home collection,28.7514,77.1129,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0323,Hinglish,reports ke baare me doctor se baat karni hai,28.4675,77.0747,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030;CG_012,0.99
S0324,Hindi,पापा को इंसुलिन लगवाना है,28.6454,77.2012,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_035,0.87
S0325,English,Post-operative dressing change required for my wife,28.6237,77.2859,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_060;CG_032,0.76
S0326,English,"Hi, is anyone there?",28.6129,77.2848,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0327,English,My father has had fever and cough for 2 days,28.6505,77.1927,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_035;CG_052,0.9
S0328,Hindi,डॉक्टर चाहिए,28.61,77.0567,,,,"Namaste! I'm here to help. Who is this for, and what's the concern — fever, a nursing need, a lab test, or a doctor consult?",Intent underspecified — asking a follow-up before deciding care type.,,
S0329,English,"Doctor prescribed an injection, can someone come home",28.4988,77.0861,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_057,0.9
S0330,English,"Grandfather is weak and not eating, want a home check-up",28.6238,77.2893,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_060,0.77
S0331,Hinglish,doctor chahiye,28.6004,77.0296,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0332,English,"Mild acidity and gas since morning, want to consult a doctor",28.6104,77.0528,teleconsultation,same_day,,,Non-urgent query suitable for a virtual doctor consult; urgency assessed as same_day.,CG_021;CG_030,0.99
S0333,Hindi,ऑपरेशन के बाद घर पर ड्रेसिंग करवानी है,28.6276,77.3107,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_060,0.8
S0334,English,Post-operative dressing change required for my wife,28.5914,77.2931,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_060,0.81
S0335,English,I want to book something for my mother,28.3924,77.3149,,,,"Happy to help. Could you tell me the main symptom or service you need (home visit, nursing, lab test, or teleconsult)?",Intent underspecified — asking a follow-up before deciding care type.,,
S0336,English,My father has had fever and cough for 2 days,28.6192,77.3086,paramedic_home_visit,same_day,,,General complaint suitable for a Medic home visit with optional virtual doctor consult; urgency assessed as same_day.,CG_060;CG_033;CG_032,0.82
S0337,Hindi,एक्सीडेंट के बाद खून नहीं रुक रहा,28.6487,77.1961,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,
S0338,Hindi,कल सुबह शुगर टेस्ट घर पर,28.7316,77.107,lab_test_home,scheduled,,,Diagnostic test requested; home sample collection; urgency assessed as scheduled.,,
S0339,Hindi,ऑपरेशन के बाद घर पर ड्रेसिंग करवानी है,28.6436,77.3877,home_nursing,same_day,,,Specific nursing procedure requested; Medic home visit; urgency assessed as same_day.,CG_026;CG_010,0.93
S0340,English,My father is having severe chest pain and can't breathe,28.6441,77.3608,emergency_112,emergency,chest_pain;breathlessness,,"Red-flag symptoms detected (chest_pain, breathlessness); routed to emergency services, not home care.",,`;

export function parseTrainingDataset(csvContent: string = RAW_TRAINING_CSV): TrainingSample[] {
  const lines = csvContent.trim().split('\n');
  const samples: TrainingSample[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Handle CSV quoting
    const tokens: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let c = 0; c < line.length; c++) {
      const char = line[c];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        tokens.push(cur);
        cur = '';
      } else {
        cur += char;
      }
    }
    tokens.push(cur);

    if (tokens.length >= 10) {
      const [
        id,
        detected_language,
        user_input,
        latStr,
        lngStr,
        care_type,
        urgency,
        red_flags_str,
        follow_up_question,
        reasoning,
        matched_caregiver_ids_str,
        top_score_str
      ] = tokens;

      samples.push({
        id,
        detected_language: detected_language as DetectedLanguage,
        user_input: user_input.replace(/^"|"$/g, ''),
        lat: parseFloat(latStr),
        lng: parseFloat(lngStr),
        care_type: (care_type ? care_type : null) as CareType,
        urgency: (urgency ? urgency : null) as Urgency,
        red_flags: red_flags_str ? red_flags_str.split(';').filter(Boolean) : [],
        follow_up_question: follow_up_question ? follow_up_question.replace(/^"|"$/g, '') : null,
        reasoning: reasoning ? reasoning.replace(/^"|"$/g, '') : '',
        matched_caregiver_ids: matched_caregiver_ids_str ? matched_caregiver_ids_str.split(';').filter(Boolean) : [],
        top_score: top_score_str ? parseFloat(top_score_str) : null
      });
    }
  }

  return samples;
}

export const TRAINING_DATASET = parseTrainingDataset();
